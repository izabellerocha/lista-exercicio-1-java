﻿Lista de participante do grupo:
1°: Nátali Isaltino Gomes | RA: 4231925815
2°: Vinícius Rapahael Rios de Lima | RA: 4231921318
3°: Vinivius de Oliveira Santos | RA: 423115981
4°: Felipe Claver Diniz | RA: 4231920565
5°: Lavínia Lucia Martins | RA: 4231921560
6°: Vanderson dos Santos Nobre Muniz
 | RA:
4231920390
7°: Diego Maia Schiavo | RA:4231924853